import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// Cambia el nombre '/tete-dog-toys/' si usas otro nombre de repositorio en GitHub
export default defineConfig({
  plugins: [react()],
  base: '/tete-dog-toys/',
})
