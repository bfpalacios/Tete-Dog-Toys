import { useState } from "react";

export default function TeteDogToysLanding() {
  const [openFAQ, setOpenFAQ] = useState(0);

  const faqs = [
    {
      q: "¿Cómo personalizo colores y tallas?",
      a: "Escríbenos por WhatsApp o Instagram para ver el catálogo de telas recicladas disponibles y escoger el tamaño ideal para tu perrito.",
    },
    {
      q: "¿Cómo cuido los juguetes?",
      a: "Lavado a mano con agua fría y jabón neutro. Secar a la sombra. No usar blanqueadores.",
    },
    {
      q: "¿Hacen envíos a domicilio?",
      a: "Sí, realizamos envíos locales. Consulta cobertura y tarifas al momento de tu pedido.",
    },
  ];

  return (
    <main className="min-h-screen bg-white text-neutral-900">
      {/* Header */}
      <header className="sticky top-0 z-30 backdrop-blur supports-[backdrop-filter]:bg-white/70 bg-white/80 border-b border-neutral-200">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            {/* Logo */}
            <img src="/logo.png" alt="Teté Dog Toys logo" className="h-10 w-10 rounded-full object-cover ring-1 ring-neutral-200 bg-white"/>
            <div className="leading-4">
              <p className="font-bold">Teté Dog Toys</p>
              <p className="text-xs text-neutral-600">Juguetes eco-amorosos para perros felices</p>
            </div>
          </div>
          <nav className="hidden md:flex items-center gap-6 text-sm">
            <a href="#productos" className="hover:text-emerald-700">Productos</a>
            <a href="#impacto" className="hover:text-emerald-700">Impacto</a>
            <a href="#blog" className="hover:text-emerald-700">Blog</a>
            <a href="#contacto" className="hover:text-emerald-700">Contacto</a>
          </nav>
          <a href="#contacto" className="inline-flex items-center rounded-xl border border-emerald-700 px-4 py-2 text-sm font-semibold hover:bg-emerald-700 hover:text-white transition-all">Comprar</a>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10 bg-gradient-to-b from-emerald-50 to-white"/>
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-14 lg:py-20 grid lg:grid-cols-12 gap-10 items-center">
          <div className="lg:col-span-7">
            <h1 className="text-4xl/tight md:text-5xl font-black tracking-tight">
              Juguetes hechos con <span className="text-emerald-700">material reciclado</span>.
            </h1>
            <p className="mt-4 text-lg text-neutral-700">
              Huesitos, jaladores y cojines diseñados para reducir el estrés de tu perrito, fortalecer el vínculo y cuidar el planeta.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <a href="#productos" className="px-5 py-3 rounded-xl bg-emerald-700 text-white font-semibold hover:shadow-lg">Ver productos</a>
              <a href="#impacto" className="px-5 py-3 rounded-xl border border-neutral-300 font-semibold hover:border-neutral-800">Nuestro impacto</a>
            </div>
            <ul className="mt-6 grid sm:grid-cols-3 gap-2 text-sm text-neutral-700">
              <li className="flex items-center gap-2"><span aria-hidden className="h-2.5 w-2.5 rounded-full bg-emerald-600"/> Hechos a mano</li>
              <li className="flex items-center gap-2"><span aria-hidden className="h-2.5 w-2.5 rounded-full bg-emerald-600"/> Telas recicladas</li>
              <li className="flex items-center gap-2"><span aria-hidden className="h-2.5 w-2.5 rounded-full bg-emerald-600"/> Seguros y lavables</li>
            </ul>
          </div>
          <div className="lg:col-span-5">
            <div className="aspect-[4/3] w-full rounded-2xl border border-neutral-200 bg-white p-3 shadow-sm">
              <div className="h-full w-full rounded-xl bg-[url('https://images.unsplash.com/photo-1543466835-00a7907e9de1?q=80&w=1200&auto=format&fit=crop')] bg-cover bg-center" role="img" aria-label="Perro jugando con un juguete" />
            </div>
            <p className="sr-only">Imagen decorativa: perro feliz jugando con juguete suave.</p>
          </div>
        </div>
      </section>

      {/* Sobre */}
      <section id="sobre" className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid lg:grid-cols-2 gap-10 items-start">
          <div>
            <h2 className="text-2xl md:text-3xl font-extrabold">Nuestra historia</h2>
            <p className="mt-3 text-neutral-700">
              Inspirados por Teté, una abuelita que nos enseñó a reutilizar y amar a los animales, creamos juguetes seguros y duraderos con telas en desuso y yute. Cada pieza es única y está pensada para promover el juego activo y la calma.
            </p>
          </div>
          <div className="rounded-2xl border border-neutral-200 p-6">
            <h3 className="font-bold">Misión</h3>
            <p className="text-neutral-700">Fomentar el bienestar físico y emocional de los perros mediante juguetes innovadores y sostenibles.</p>
            <div className="h-px my-4 bg-neutral-200"/>
            <h3 className="font-bold">Visión</h3>
            <p className="text-neutral-700">Ser la marca ecoamigable favorita por su calidad, diseño y compromiso con el medio ambiente.</p>
          </div>
        </div>
      </section>

      {/* Productos */}
      <section id="productos" className="bg-neutral-50 border-y border-neutral-200">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
          <div className="flex items-end justify-between gap-6 flex-wrap">
            <h2 className="text-2xl md:text-3xl font-extrabold">Productos</h2>
            <p className="text-sm text-neutral-600">Colores y tallas se personalizan a pedido.</p>
          </div>

          <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Eco-Bone */}
            <article className="group rounded-2xl border border-neutral-200 bg-white p-5 hover:shadow-lg transition-all">
              <div className="aspect-[4/3] w-full rounded-xl bg-[url('https://images.unsplash.com/photo-1525253013412-55c1a69a5738?q=80&w=1200&auto=format&fit=crop')] bg-cover bg-center" />
              <h3 className="mt-4 text-lg font-bold">Eco‑Bone</h3>
              <p className="text-sm text-neutral-700">Huesito de tela reciclada, suave y resistente. Ideal para morder y relajarse.</p>
              <div className="mt-3 flex items-center justify-between">
                <span className="text-base font-semibold">S/ 25.00</span>
                <a href="#contacto" className="text-sm font-semibold text-emerald-700 group-hover:underline">Comprar</a>
              </div>
            </article>

            {/* Tira‑Teté */}
            <article className="group rounded-2xl border border-neutral-200 bg-white p-5 hover:shadow-lg transition-all">
              <div className="aspect-[4/3] w-full rounded-xl bg-[url('https://images.unsplash.com/photo-1561037404-61cd46aa615b?q=80&w=1200&auto=format&fit=crop')] bg-cover bg-center" />
              <h3 className="mt-4 text-lg font-bold">Tira‑Teté</h3>
              <p className="text-sm text-neutral-700">Juguete para jalar con trenzas de tela reciclada. Súper durable y divertido.</p>
              <div className="mt-3 flex items-center justify-between">
                <span className="text-base font-semibold">S/ 25.00</span>
                <a href="#contacto" className="text-sm font-semibold text-emerald-700 group-hover:underline">Comprar</a>
              </div>
            </article>

            {/* Huesito XXL Cojín */}
            <article className="group rounded-2xl border border-neutral-200 bg-white p-5 hover:shadow-lg transition-all">
              <div className="aspect-[4/3] w-full rounded-xl bg-[url('https://images.unsplash.com/photo-1494253188410-ff0cdea5499e?q=80&w=1200&auto=format&fit=crop')] bg-cover bg-center" />
              <h3 className="mt-4 text-lg font-bold">Huesito XXL Cojín</h3>
              <p className="text-sm text-neutral-700">Cojín grande en forma de hueso, suave y lavable. Perfecto para descansar.</p>
              <div className="mt-3 flex items-center justify-between">
                <span className="text-base font-semibold">S/ 45.00</span>
                <a href="#contacto" className="text-sm font-semibold text-emerald-700 group-hover:underline">Comprar</a>
              </div>
            </article>
          </div>

          <div className="mt-6 text-sm text-neutral-600">
            <p>* Precios base. Personalización y envío se cotizan por chat.</p>
          </div>
        </div>
      </section>

      {/* Impacto + SCAMPER */}
      <section id="impacto" className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid lg:grid-cols-2 gap-10">
          <div>
            <h2 className="text-2xl md:text-3xl font-extrabold">Impacto ambiental</h2>
            <ul className="mt-4 space-y-2 text-neutral-700">
              <li>♻️ Reutilizamos entre 30g y 120g de textil por juguete.</li>
              <li>🌱 Menos plástico, más telas recicladas y yute.</li>
              <li>🐾 Producción artesanal con materiales recuperados.</li>
            </ul>
          </div>
          <div className="rounded-2xl border border-neutral-200 p-6">
            <h3 className="font-bold">Innovación (SCAMPER)</h3>
            <ul className="mt-2 list-disc pl-5 text-neutral-700 space-y-1">
              <li><b>Sustituir:</b> plástico → telas recicladas.</li>
              <li><b>Combinar:</b> trenzas multicolor para mayor estímulo.</li>
              <li><b>Adaptar:</b> diseños reforzados según pruebas de uso.</li>
              <li><b>Modificar:</b> tallas, peso, colores y etiquetas de alta adherencia.</li>
              <li><b>Otro uso:</b> bolsas de yute reutilizables como decoración/almacenaje.</li>
            </ul>
          </div>
        </div>
      </section>

      {/* Blog/Ideas */}
      <section id="blog" className="bg-neutral-50 border-y border-neutral-200">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
          <h2 className="text-2xl md:text-3xl font-extrabold">Blog</h2>
          <div className="mt-6 grid md:grid-cols-3 gap-6">
            {[
              {
                title: "¿Por qué elegir juguetes reciclados?",
                excerpt: "Beneficios para tu perro y para el planeta al preferir materiales recuperados.",
              },
              {
                title: "Juegos para reducir el estrés en casa",
                excerpt: "Rutinas sencillas para departamentos que activan mente y cuerpo.",
              },
              {
                title: "Cómo limpiamos y preparamos las telas",
                excerpt: "Nuestro proceso para asegurar seguridad, higiene y durabilidad.",
              },
            ].map((p, i) => (
              <article key={i} className="rounded-2xl border border-neutral-200 bg-white p-5 hover:shadow-lg transition-all">
                <div className="aspect-[4/3] w-full rounded-xl bg-neutral-100"/>
                <h3 className="mt-4 text-lg font-bold">{p.title}</h3>
                <p className="text-sm text-neutral-700">{p.excerpt}</p>
                <button className="mt-3 text-sm font-semibold text-emerald-700 hover:underline">Leer más</button>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* Modelo simple de negocio */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
        <div className="rounded-2xl border border-neutral-200 p-6">
          <h2 className="text-2xl md:text-3xl font-extrabold">Modelo simple de negocio</h2>
          <div className="mt-4 grid md:grid-cols-4 gap-4 text-sm">
            <div className="rounded-xl bg-emerald-50 p-4">
              <p className="font-semibold">Costo unitario</p>
              <p className="text-neutral-700">≈ S/ 16.00</p>
            </div>
            <div className="rounded-xl bg-emerald-50 p-4">
              <p className="font-semibold">Precio sugerido</p>
              <p className="text-neutral-700">S/ 25.00</p>
            </div>
            <div className="rounded-xl bg-emerald-50 p-4">
              <p className="font-semibold">Margen aprox.</p>
              <p className="text-neutral-700">56%</p>
            </div>
            <div className="rounded-xl bg-emerald-50 p-4">
              <p className="font-semibold">Punto de equilibrio</p>
              <p className="text-neutral-700">≈ 14 unidades</p>
            </div>
          </div>
          <p className="mt-3 text-xs text-neutral-600">Valores de referencia basados en el primer lote de 50 unidades.</p>
        </div>
      </section>

      {/* CTA de compra */}
      <section id="contacto" className="bg-emerald-700 text-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-14">
          <div className="grid lg:grid-cols-2 gap-10 items-center">
            <div>
              <h2 className="text-3xl font-extrabold">¿Listo para consentir a tu engreído?</h2>
              <p className="mt-3 text-emerald-50">Contáctanos para ver telas disponibles, tallas y personalización. Envíos locales.</p>
              <div className="mt-6 flex flex-wrap gap-3">
                <a href="https://wa.me/51995605669" target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-xl bg-white text-emerald-800 font-semibold px-5 py-3 hover:shadow-lg">
                  <span aria-hidden>💬</span> WhatsApp (Gianluca Sanchez Torres)
                </a>
                <a href="https://instagram.com/" target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-xl border border-white/80 px-5 py-3 font-semibold hover:bg-white hover:text-emerald-800">
                  <span aria-hidden>📷</span> Instagram
                </a>
              </div>
            </div>
            <form className="rounded-2xl bg-white/10 p-6 backdrop-blur">
              <div className="grid md:grid-cols-2 gap-4">
                <label className="text-sm">Nombre
                  <input className="mt-1 w-full rounded-lg border border-white/40 bg-white/90 text-neutral-900 px-3 py-2" placeholder="Tu nombre" />
                </label>
                <label className="text-sm">Email
                  <input type="email" className="mt-1 w-full rounded-lg border border-white/40 bg-white/90 text-neutral-900 px-3 py-2" placeholder="tucorreo@dominio.com" />
                </label>
              </div>
              <label className="text-sm block mt-4">Mensaje
                <textarea className="mt-1 w-full rounded-lg border border-white/40 bg-white/90 text-neutral-900 px-3 py-2" rows={4} placeholder="Quiero un Eco‑Bone talla M, ¿qué colores tienen?"/>
              </label>
              <button type="button" className="mt-4 w-full rounded-xl bg-white text-emerald-800 font-semibold px-5 py-3 hover:shadow-lg">Enviar</button>
              <p className="mt-2 text-xs text-emerald-50">* El formulario es demostrativo. Conéctalo a tu backend o a un servicio de formularios.</p>
            </form>
          </div>
        </div>
      </section>

      {/* FAQs */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
        <h2 className="text-2xl md:text-3xl font-extrabold">Preguntas frecuentes</h2>
        <div className="mt-6 divide-y divide-neutral-200 rounded-2xl border border-neutral-200 overflow-hidden">
          {faqs.map((f, i) => (
            <details key={i} open={openFAQ === i} onClick={() => setOpenFAQ(openFAQ === i ? null : i)} className="group">
              <summary className="cursor-pointer list-none select-none px-5 py-4 flex items-center justify-between">
                <span className="font-semibold">{f.q}</span>
                <span aria-hidden className="transition-transform group-open:rotate-45 text-2xl leading-none">+</span>
              </summary>
              <div className="px-5 pb-5 text-neutral-700">{f.a}</div>
            </details>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-neutral-950 text-neutral-200">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10 grid md:grid-cols-3 gap-6 items-start">
          <div>
            <p className="font-bold">Teté Dog Toys</p>
            <p className="text-sm text-neutral-400 mt-2">Hechos a mano con telas recicladas. Lima, Perú.</p>
          </div>
          <div>
            <p className="font-semibold">Navegación</p>
            <ul className="mt-2 space-y-1 text-sm text-neutral-300">
              <li><a href="#productos" className="hover:underline">Productos</a></li>
              <li><a href="#impacto" className="hover:underline">Impacto</a></li>
              <li><a href="#blog" className="hover:underline">Blog</a></li>
              <li><a href="#contacto" className="hover:underline">Contacto</a></li>
            </ul>
          </div>
          <div>
            <p className="font-semibold">Contacto</p>
            <ul className="mt-2 space-y-1 text-sm text-neutral-300">
              <li>WhatsApp: +51 995 605 669</li>
              <li>Instagram: @tete.dog.toys</li>
              <li>Email: gianluca.sanchez@tetedogtoys.pe</li>
            </ul>
          </div>
        </div>
        <div className="border-t border-neutral-800">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-6 text-xs text-neutral-500 flex flex-wrap items-center justify-between gap-4">
            <p>© {new Date().getFullYear()} Teté Dog Toys. Todos los derechos reservados.</p>
            <p>Hecho con ❤️ y telas recicladas.</p>
          </div>
        </div>
      </footer>
    </main>
  );
}
