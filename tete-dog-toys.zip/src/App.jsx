import TeteDogToysLanding from './TeteDogToysLanding'

export default function App() {
  return <TeteDogToysLanding />
}
