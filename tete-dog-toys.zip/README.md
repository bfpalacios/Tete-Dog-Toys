# Teté Dog Toys – Landing Page (React + Vite + Tailwind)

## Desarrollo local
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
npm run preview
```

## Publicar en GitHub Pages
1. Sube este contenido a un repo llamado **tete-dog-toys** (o cambia `base` en `vite.config.js` si usas otro nombre).
2. Asegúrate que **Settings → Pages** esté en **GitHub Actions**.
3. Haz push a `main` y espera a que termine el workflow.
4. Tu sitio estará en: `https://<tu-usuario>.github.io/<nombre-del-repo>/`.
